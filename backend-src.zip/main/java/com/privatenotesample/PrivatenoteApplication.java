package com.privatenotesample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PrivatenoteApplication {

    public static void main(String[] args) {
        SpringApplication.run(PrivatenoteApplication.class, args);
    }

}
