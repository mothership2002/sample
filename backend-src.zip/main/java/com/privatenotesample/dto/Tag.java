package com.privatenotesample.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Tag {

    private Long tagId;
    private String TagData;

}
